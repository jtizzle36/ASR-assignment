import re
import random

random.seed(42)

# Size of training data sample (e.g., 120 total)
train_size = 120
mix_train_size = int(train_size / 2)
test_size = 8
mix_test_size = int(test_size / 2)
assert(train_size%2==0 and test_size%2==0)

# Rename spk2gender from training data to spk2gender_train
f_spk = []
m_spk = []
with open("spk2gender_train", "r") as f:
    for line in f:
        spk = re.search("\w+\d", line).group(0)
        fc = len(f_spk)
        mc = len(m_spk)
        if spk[0] == 'f':
            f_spk.append(spk)
        elif spk[0] == 'm':
            m_spk.append(spk)

random.shuffle(m_spk)
random.shuffle(f_spk)

mix_spk = []
for i in range(mix_train_size):
    mix_spk.append(m_spk[i])
    mix_spk.append(f_spk[i])

random.shuffle(m_spk)
random.shuffle(f_spk)

m_spk = m_spk[:train_size]
f_spk = f_spk[:train_size]

'''
with open("f_train", "w+") as f:
    for spk in f_spk:
        f.write(spk)
        f.write("\n")

with open("m_train", "w+") as f:
    for spk in m_spk:
        f.write(spk)
        f.write("\n")
'''
with open("mix_train", "w+") as f:
    for spk in mix_spk:
        f.write(spk)
        f.write("\n")

# Rename spk2gender from test data to spk2gender_test
f_spk = []
m_spk = []
mix_spk = []

with open("spk2gender_test", "r") as f:
    for line in f:
        spk = re.search("\w+\d", line).group(0)
        fc = len(f_spk)
        mc = len(m_spk)
        if spk[0] == 'f':
            f_spk.append(spk)
        elif spk[0] == 'm':
            m_spk.append(spk)

random.shuffle(m_spk)
random.shuffle(f_spk)

mix_spk = []
for i in range(mix_test_size):
    mix_spk.append(m_spk[i])
    mix_spk.append(f_spk[i])

random.shuffle(m_spk)
random.shuffle(f_spk)

m_spk = m_spk[:test_size]
f_spk = f_spk[:test_size]
'''
with open("f_test", "w+") as f:
    for spk in f_spk:
        f.write(spk)
        f.write("\n")

with open("m_test", "w+") as f:
    for spk in m_spk:
        f.write(spk)
        f.write("\n")
'''
with open("mix_test", "w+") as f:
    for spk in mix_spk:
        f.write(spk)
        f.write("\n")
